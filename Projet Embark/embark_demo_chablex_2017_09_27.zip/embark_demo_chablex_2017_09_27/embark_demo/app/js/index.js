//Afficher une durée à partir d'un nombre de secondes
function secToStr(nbSecondes){
  var d = new Date(1970, 0, 1);
  d.setSeconds(nbSecondes);
  var dayDiff = Math.trunc((d - new Date(1970, 0, 1))/(1000*60*60*24));
  var str = (dayDiff > 0) ? dayDiff + " J " : "";
  return  str + d.getHours() + " H " + d.getMinutes() + " Min "  + d.getSeconds() + " Sec";
}

// source : https://www.w3schools.com/howto/howto_js_sort_table.asp
  function sortTable(selector,n) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
    table = document.getElementById(selector);
    switching = true;
    //Set the sorting direction to ascending:
    dir = "asc";
    /*Make a loop that will continue until
    no switching has been done:*/
    while (switching) {
      //start by saying: no switching is done:
      switching = false;
      rows = table.getElementsByTagName("TR");
      /*Loop through all table rows (except the
      first, which contains table headers):*/
      for (i = 1; i < (rows.length - 1); i++) {
        //start by saying there should be no switching:
        shouldSwitch = false;
        /*Get the two elements you want to compare,
        one from current row and one from the next:*/
        x = rows[i].getElementsByTagName("TD")[n];
        y = rows[i + 1].getElementsByTagName("TD")[n];
        /*check if the two rows should switch place,
        based on the direction, asc or desc:*/
        if (dir == "asc") {
          if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
            //if so, mark as a switch and break the loop:
            shouldSwitch= true;
            break;
          }
        } else if (dir == "desc") {
          if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
            //if so, mark as a switch and break the loop:
            shouldSwitch= true;
            break;
          }
        }
      }
      if (shouldSwitch) {
        /*If a switch has been marked, make the switch
        and mark that a switch has been done:*/
        rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
        switching = true;
        //Each time a switch is done, increase this count by 1:
        switchcount ++;
      } else {
        /*If no switching has been done AND the direction is "asc",
        set the direction to "desc" and run the while loop again.*/
        if (switchcount == 0 && dir == "asc") {
          dir = "desc";
          switching = true;
        }
      }
    }
  }


$(document).ready(function() {
  /*
    Simulation pour la gestion des comptes ETH
  */

  //Affichage de la liste d'adresses ETH utilisables
  for (var i = 0; i < 10; i++){
    $("#numSimulationAdresse").append("<option>"+web3.eth.accounts[i]+"</option>");
  }

  var monCompte = $("#numSimulationAdresse").val();

  //Gestion du changement de l'adresse ETH utilisée
  function changeAdresseSimulee(){
    monCompte = $("#numSimulationAdresse").val();
    ChabToken.owner().then(function(value) {
        if (value == monCompte){
            $("#actionsDemarage").show();
        } else {
            $("#actionsDemarage").hide();
        }
        $("input[type='text']").val("");
        affichageInfoCompte();
    });

  }
  $("#numSimulationAdresse").change(changeAdresseSimulee);
  changeAdresseSimulee();


  /*
    Chargement des contantes du smart contract
  */
  var tempsMinChangeMax;
  ChabToken.tempsMinChangeMax({from : monCompte}).then(function(value) {
      tempsMinChangeMax = value.c[0];
  });

  /*
    Affichage de la périodeQ1
  */

  var oldResult = 0;
  var tempsInactivite = 0;
  var timer = setInterval(function() {
    ChabToken.getTimeLeftInQ1({from : monCompte}).then(function(value) {
        if(value.c[0]-tempsInactivite > 0){
              tempsInactivite = (oldResult == value.c[0])? tempsInactivite+1:0;
            $("#infoPeriodQ1Value").html("ce termine dans : "+secToStr(value.c[0]-tempsInactivite));
            oldResult = value.c[0];
        } else {
          $("#infoPeriodQ1Value").html("est terminée");
          clearInterval(timer);
        }
    });
  }, 1000);

/*******************************************************************************
  PARTIE WALLET :
*******************************************************************************/

/*
  Affichage dee la liste des demandes
*/
function afficherDemandes(){
  ChabToken.getNbDemandes({from : monCompte}).then(function(value0) {
    var nbDemandes = value0.c[0];
    $(".trDemande").remove();
    var iAsync = 0;
    if (nbDemandes == 0)
      $("#listeDemandes").append("<tr class='trDemande'><td>-</td><td>Aucune demande</td><td>-</td></tr>");
    for (var i = 0; i < nbDemandes; i++){
      ChabToken.getDemande(i,{from : monCompte}).then(function(value1) {
        $("#listeDemandes").append("<tr class='trDemande'><td>"+ iAsync++ +"</td><td>"+ value1[0] +"</td><td>"+value1[1].c[0]+"</td></tr>");

      });
    }
  }).then(function() {
    sortTable("listeDemandes",0);
  });
}
$("#btnPrintDemandes").click(afficherDemandes);
$("#lienMembres").click(afficherDemandes);
afficherDemandes();

/*
  Affichage des info du compte
*/
  var avertirAvantPreter = false;
  function affichageInfoCompte(){
    var demandes;
    var emprunts;
    var rembourssements;
    ChabToken.balanceOf(monCompte,{from:monCompte}).then(function(value) {
      $("#balanceVal").html(value.c[0]);
    });
    ChabToken.demandes(monCompte,{from:monCompte}).then(function(value) {
      demandes = value.c[0];
      $("#demandesVal").html(demandes);
    }).then(function(){
      ChabToken.emprunts(monCompte,{from:monCompte}).then(function(value) {
        emprunts = value.c[0];
        $("#empruntsVal").html(value.c[0]);
         if (demandes >  value.c[0])
           $("#flagDemandeEnCours").show();
           else
            $("#flagDemandeEnCours").hide();
      }).then(function(){
        ChabToken.remboursements(monCompte,{from:monCompte}).then(function(value) {
          rembourssements = value.c[0];
          $("#remboursementsVal").html(value.c[0]);

        }).then(function(){
          ChabToken.getMaxEmpruntable(monCompte,{from:monCompte}).then(function(value) {
            if (emprunts - rembourssements >= value.c[0] && value.c[0] > 0)
              $("#flagMaxEmprunte").show();
            else
              $("#flagMaxEmprunte").hide();
            $("#maxEmpruntableVal").html(value.c[0]);
          }).then(function(){
            ChabToken.dateChangementMax(monCompte,{from:monCompte}).then(function(value) {
              ChabToken.getTime({from:monCompte}).then(function(value2) {
                var txtDate = "";
                $("#maxEmpruntableDate").css("color","black");
                if (value.c[0] <= 0){
                  txtDate = "Etat initial";
                  avertirAvantPreter = false;
                }
                else {
                  var nbSecRestantes = ((value.c[0] + tempsMinChangeMax) - value2.c[0]);
                  if (nbSecRestantes > 0){
                    txtDate = "Ne peut plus augmenter </br> (avant : " + secToStr(nbSecRestantes) + ")";
                    $("#maxEmpruntableDate").css("color","red");
                    avertirAvantPreter = true;
                  } else {
                    txtDate = "Peut augmenter </br> (si vous prêter la valeur du max actuel)";
                    avertirAvantPreter = false;
                  }
                  nbSecRestantes = (nbSecRestantes > 0)? nbSecRestantes : 0 ;

                }
                $("#maxEmpruntableDate").html(txtDate);
              });
            });
          });
        });
      });
    });
  }
  $("#btnPrintInfoCompte").click(affichageInfoCompte);
  $("#lienWallet").click(affichageInfoCompte);

  /*
    Actions sur le wallet
  */
  function preterCHT(){
    var confirmed;
    if (avertirAvantPreter)
      confirmed = confirm("Vous ne pouvez pas encore augmenter votre maximum empruntable, il vous est recommandé d'attendre avant de prêter!");

    if (avertirAvantPreter == false || confirmed){
      ChabToken.preter($("#preterValeur").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
        console.log("Action accomplie");
        affichageInfoCompte();
        afficherDemandes();
      }).catch(function(error){
        alert("Erreur : \n   Assurez vous : \n"+
        "      (1) d'être membre \n"+
        "      (2) que la période Q1 est terminée \n"+
        "      (3) que le prêt soit un nombre positif \n"+
        "      (4) que vous possédez suffisament de CHT \n"+
        "      (5) que le prêt ne tente pas de répondre à l'une de vos demandes \n"+
        "      (6) que le prêt ne dépasse pas le total des demandes en cours");
        console.log("errorCatch");
        console.log(error);
      });
    }
  }
  $("#btnWalletPreter").click(preterCHT);

  function demanderCHT(){
    ChabToken.demander($("#demanderValeur").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
      console.log("Action accomplie");
      affichageInfoCompte();
      afficherDemandes();
    }).catch(function(error){
      alert("Erreur : \n   Assurez vous : \n"+
      "      (1) d'être membre \n"+
      "      (2) que la période Q1 est terminée \n"+
      "      (3) que vous n'avez pas demandé plus que votre max empruntable \n"+
      "      (4) que vos n'avez pas déjà atteint votre max empruntable \n"+
      "      (5) que le total demandé par la communauté ne dépassera pas 1/3 du nombre total de tokens");
      console.log("errorCatch");
      console.log(error);
    });
  }
  $("#btnWalletDemander").click(demanderCHT);

  function envoyerCHT(){
    ChabToken.transfer($("#envoyerAdresse").val(),$("#envoyerValeur").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
      console.log("Action accomplie");
      affichageInfoCompte();
    }).catch(function(error){
      alert("Erreur : \n   Assurez vous : \n"+
      "      (1) d'être membre \n"+
      "      (2) que l'adresse de destination appartienne à un membre \n"+
      "      (3) que la période Q1 est terminée \n"+
      "      (4) que vous possédez suffisament de CHT \n"+
      "      (5) que le montant est un nombre (et n'est pas négatif)");
      console.log("errorCatch");
      console.log(error);
    });
  }
  $("#btnWalletEnvoyer").click(envoyerCHT);

/*******************************************************************************
  PARTIE MEMBRES :
*******************************************************************************/

/*
  Proposition et vote
*/

//Demander au smart contract de clore un vote
function executerProposition(){
  if($.trim($("#idPropositionToExec").val()).length>0){
    ChabToken.executeProposal($("#idPropositionToExec").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
      console.log("Action accomplie");
      afficherPropositions();
      afficherMembres();
    }).catch(function(error){
      ChabToken.minimumQuorum().then(function(value){
        alert("Erreur : \n   Assurez vous : \n"+
        "      (1) que la periode Q1 soit terminée \n"+
        "      (2) une proposition possède bien cet ID \n"+
        "      (3) la proposition a au moins 7 jours \n"+
        "      (4) la proposition est dans l'état \"En cours\" \n"+
        "      (5) la proposition a déjà reçu au moins "+ value.c[0] +" votes");
        console.log("errorCatch");
        console.log(error);
      });
    });
  } else {
    alert("Veuillez indiquer l'identifiant (numéro) de la proposition.")
  }
}

$("#btnExecuterProposition").click(executerProposition);


function afficherPropositions(){
  ChabToken.numProposals({from : monCompte}).then(function(value0) {
    nbPropositions = value0.c[0];
    $(".trProposition").remove();
    $(".trInfoVotes").remove();
    for (var i = 0; i < nbPropositions; i++){
      ChabToken.proposals(i,{from : monCompte}).then(function(value1) {
        var etatText = "";
        if (value1[4] == true) //si la proposition est déjà executée
          etatText = (value1[5])? "Acceptée" : "Refusée";
        else
          etatText = "En cours";
        var nbVotes = value1[6].c[0];
        var pourcentActuel = (nbVotes>0) ? Math.trunc(value1[7].c[0] / nbVotes * 100) + " %" : "0 %";
        var nbVotesTraite = 0;
        for (var j = 0; j < nbVotes; j++){
          ChabToken.getVoteFromProposal(value1[0].c[0], j, {from : monCompte}).then(function(value2) {
            var avisTxt = (value2[1])? "Acceptation" : "Refus";
            $("#listePropositionInfo").append("<tr class='trInfoVotes infoVotes"+value1[0].c[0]+"'><td>"+value2[0]+"</td><td class='avis"+avisTxt+"'>"+avisTxt+"</td><td>"+value2[2]+"</td></tr>");
            $(".infoVotes"+value1[0].c[0]).hide();
            if (nbVotesTraite+1 >= nbVotes){ // Si c'est le dernier passage dans la boucle
              $("#listePropositions").append("<tr class='trProposition'><td>"+value1[0].c[0]+"</td><td>"+value1[2]+"</td><td>"+value1[1]+"</td><td>"+etatText+"</td><td><button id='detailPropo"+value1[0].c[0]+"' class='lienDetail'>"+nbVotes+"</button></td><td>"+pourcentActuel+"</td></tr>");
              $("#detailPropo"+value1[0].c[0]).click(function(e){
                $(".infoVotes"+value1[0].c[0]).toggle();
                $("#listePropositionInfo").toggle();
                $("#listePropositionInfo").css({left:e.pageX-504,top:e.pageY+13,position:"fixed"});
              });
            }
            nbVotesTraite++;
          });
        }

      });
    }
  }).then(function() {
    sortTable("listePropositions",0);
  });
}

$("#btnPrintPropositions").click(afficherPropositions);
$("#lienMembres").click(afficherPropositions);
afficherPropositions();

function voter(){
  if($.trim($("#idProposition").val()).length>0){
    ChabToken.vote($("#idProposition").val(),($( "input[name$='vote']:checked").val()==1),$("#justification").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
      console.log("Action accomplie");
      afficherPropositions();
    }).catch(function(error){
      alert("Erreur : \n   Assurez vous : \n"+
      "      (1) d'être membre \n"+
      "      (2) que la periode Q1 soit terminée \n"+
      "      (3) qu'une proposition corresponde à l'ID saisi \n"+
      "      (4) que vous n'avez pas déja voté pour cette proposition");
      console.log("errorCatch");
      console.log(error);
    });
  } else {
    alert("Veuiller indiquer l'identifiant (numéro) de la proposition.")
  }
}
$("#btnVoter").click(voter);

  function proposerMembre(){
    if($.trim($("#proposerAdresse").val()).length>0 && $.trim($("#proposerNom").val()).length>0){
      ChabToken.newProposal($("#proposerAdresse").val(),$("#proposerNom").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
        console.log("Action accomplie");
        afficherPropositions();
      }).catch(function(error){
        alert("Erreur : \n   Assurez vous : \n"+
        "      (1) d'être membre \n"+
        "      (2) que la periode Q1 soit terminée \n"+
        "      (3) que l'adresse ETH n'est pas déja utilisée par un membre \n"+
        "      (4) que vous n'avez pas fait de proposition depuis 7 jours");
        console.log("errorCatch");
        console.log(error);
      });
    } else {
      alert("Veuillez indiquer un nom d'entreprise et son adresse ETH.")
    }
  }
  $("#btnProposerMembre").click(proposerMembre);

/*
  Membres et actions de démarrage :
*/
  function afficherMembres(){
    ChabToken.getMembersCount().then(function(value0) {
      nbMembres = value0.c[0];
      $(".trMembre").remove();
      for (var i = 1; i <= nbMembres; i++){
        ChabToken.members(i,{from:monCompte}).then(function(value1) {
          ChabToken.balanceOf(value1[0],{from:monCompte}).then(function(value2) {
            $("#listeMembres").append("<tr class='trMembre'><td>"+value1[1]+"</td><td>"+value1[0]+"</td><td>"+value2.c[0]+" CHT</td></tr>");
          });
        });
      }
    }).then(function() {
      sortTable("listeMembres",0);
    });
  }
  $("#btnPrintMembres").click(afficherMembres);
  $("#lienMembres").click(afficherMembres);

  function ajouterMembre(){
    if($.trim($("#ajouterAdresse").val()).length>0 && $.trim($("#ajouterNom").val()).length>0){
      ChabToken.addMember($("#ajouterAdresse").val(),$("#ajouterNom").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
          console.log("Action accomplie");
          afficherMembres();
      }).catch(function(error){
        alert("Erreur : \n   Assurez vous : \n"+
        "      (1) d'être le propriétaire du contrat \n"+
        "      (2) que la periode Q1 ne soit pas terminée \n"+
        "      (3) que l'adresse ETH ne soit pas déja utilisée par un membre");
        console.log("errorCatch");
        console.log(error);
      });
    } else {
      alert("Veuiller indiquer un nom d'entreprise et son adresse ETH.")
    }
  }
  $("#btnAjouterMembre").click(ajouterMembre);

  function distribuerCHT(){
    ChabToken.mint($("#distribAdresse").val(),$("#distribValeur").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
      console.log("Action accomplie");
      afficherMembres();
    }).catch(function(error){
      alert("Erreur : \n   Assurez vous : \n"+
      "      (1) d'être le propriétaire du contrat \n"+
      "      (2) que la periode Q1 ne soit pas terminée \n"+
      "      (3) qu'un membre possède bien cette adresse ETH ");
      console.log("errorCatch");
      console.log(error);
    });
  }

  $("#btnMembreEnvoyerCHT").click(distribuerCHT);

  function supprimerMembre(){
    ChabToken.removeMember($("#supprimerAdresse").val(),{from:monCompte,gas:4712388,gasPrice:10^11}).then(function(value) {
        console.log("Action accomplie");
        afficherMembres();
    }).catch(function(error){
      alert("Erreur : \n   Assurez vous : \n"+
      "      (1) d'être le propriétaire du contrat \n"+
      "      (2) que la periode Q1 ne soit pas terminée \n"+
      "      (3) que l'adresse ETH est bien celle d'un membre");
      console.log("errorCatch");
      console.log(error);
    });
  }
  $("#btnSupprimerMembre").click(supprimerMembre);


  afficherMembres(); //Affiche les membres une première fois

});
